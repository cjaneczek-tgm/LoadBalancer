package balance.bbehavior;

import java.util.HashMap;

public class LCSSTBehavior implements BalancerBehavior {


	@Override
	public String useBalance(HashMap<Integer,String> loadFactor) {
		return null;
	}
}
