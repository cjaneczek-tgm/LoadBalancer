package balance.bbehavior;

import java.util.HashMap;

public class WLCBehavior implements BalancerBehavior {


	@Override
	public String useBalance(HashMap<Integer,String> loadFactor) {
		return null;
	}
}
